"""
prepare_data.py
----------------
Downloads the Garbage Classification (TrashNet-style) dataset from Kaggle
and splits it into train / validation / test folders ready for
torchvision.datasets.ImageFolder.

BEFORE RUNNING:
1. Create a free Kaggle account (kaggle.com) if you don't have one.
2. Go to Kaggle -> your profile picture -> Settings -> API -> "Create New Token".
   This downloads a file called kaggle.json.
3. Upload kaggle.json to your Colab session (or place it in ~/.kaggle/ locally).

Usage:
    python prepare_data.py
"""

import os
import shutil
import random
from pathlib import Path

DATASET_SLUG = "mostafaabla/garbage-classification"  # Kaggle dataset identifier
RAW_DIR = Path("data/raw")
SPLIT_DIR = Path("data/split")
TRAIN_RATIO = 0.7
VAL_RATIO = 0.15
# remaining ~0.15 goes to test
SEED = 42


def download_dataset():
    """Downloads and unzips the dataset from Kaggle into data/raw/."""
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    print(f"Downloading '{DATASET_SLUG}' from Kaggle...")
    os.system(f"kaggle datasets download -d {DATASET_SLUG} -p {RAW_DIR} --unzip")
    print("Download complete.")


def split_dataset():
    """Splits images in data/raw/<class>/ into train/val/test folders."""
    random.seed(SEED)

    # Find the folder that actually contains class subfolders
    # (Kaggle zips sometimes nest an extra folder level)
    candidates = [p for p in RAW_DIR.iterdir() if p.is_dir()]
    source_root = candidates[0] if len(candidates) == 1 else RAW_DIR

    class_dirs = [d for d in source_root.iterdir() if d.is_dir()]
    if not class_dirs:
        raise RuntimeError(
            f"No class folders found under {source_root}. "
            "Check that the Kaggle download succeeded and inspect data/raw/ manually."
        )

    print(f"Found {len(class_dirs)} classes: {[d.name for d in class_dirs]}")

    for split in ["train", "val", "test"]:
        (SPLIT_DIR / split).mkdir(parents=True, exist_ok=True)

    for class_dir in class_dirs:
        images = list(class_dir.glob("*.*"))
        random.shuffle(images)

        n = len(images)
        n_train = int(n * TRAIN_RATIO)
        n_val = int(n * VAL_RATIO)

        splits = {
            "train": images[:n_train],
            "val": images[n_train:n_train + n_val],
            "test": images[n_train + n_val:],
        }

        for split, files in splits.items():
            out_dir = SPLIT_DIR / split / class_dir.name
            out_dir.mkdir(parents=True, exist_ok=True)
            for f in files:
                shutil.copy(f, out_dir / f.name)

        print(f"  {class_dir.name}: {n} images -> "
              f"train={len(splits['train'])}, val={len(splits['val'])}, test={len(splits['test'])}")

    print(f"\nDone. Split dataset ready at: {SPLIT_DIR.resolve()}")


if __name__ == "__main__":
    if not RAW_DIR.exists() or not any(RAW_DIR.iterdir()):
        download_dataset()
    else:
        print("data/raw already populated, skipping download.")

    split_dataset()
