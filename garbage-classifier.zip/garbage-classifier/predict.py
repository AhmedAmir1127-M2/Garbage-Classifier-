"""
predict.py
----------
Run inference on a single image using the trained model.

Usage:
    python predict.py --image path/to/image.jpg
"""

import argparse
import json
from pathlib import Path

import torch
import torch.nn as nn
from torchvision import transforms, models
from PIL import Image

MODEL_DIR = Path("models")
IMG_SIZE = 224


def load_model():
    with open(MODEL_DIR / "class_names.json") as f:
        class_names = json.load(f)

    model = models.resnet18(weights=None)
    model.fc = nn.Linear(model.fc.in_features, len(class_names))
    model.load_state_dict(torch.load(MODEL_DIR / "best_model.pth", map_location="cpu"))
    model.eval()

    return model, class_names


def predict(image_path, model, class_names, top_k=3):
    transform = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(IMG_SIZE),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])

    image = Image.open(image_path).convert("RGB")
    tensor = transform(image).unsqueeze(0)

    with torch.no_grad():
        outputs = model(tensor)
        probs = torch.softmax(outputs, dim=1)[0]

    top_probs, top_idxs = torch.topk(probs, k=min(top_k, len(class_names)))
    results = [(class_names[i], p.item()) for p, i in zip(top_probs, top_idxs)]

    return results


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--image", required=True, help="Path to an image file")
    parser.add_argument("--top_k", type=int, default=3)
    args = parser.parse_args()

    model, class_names = load_model()
    results = predict(args.image, model, class_names, args.top_k)

    print(f"\nPredictions for {args.image}:\n")
    for label, prob in results:
        print(f"  {label:12s} {prob*100:5.1f}%")
