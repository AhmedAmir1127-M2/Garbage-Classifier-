"""
app.py
------
Interactive web demo for the garbage classifier using Gradio.
Upload an image and get a live prediction with confidence scores.

Usage:
    python app.py

Then open the local URL Gradio prints (usually http://127.0.0.1:7860).
Add share=True in demo.launch() below to get a public shareable link.
"""

import json
from pathlib import Path

import torch
import torch.nn as nn
import gradio as gr
from torchvision import transforms, models
from PIL import Image

MODEL_DIR = Path("models")
IMG_SIZE = 224

with open(MODEL_DIR / "class_names.json") as f:
    CLASS_NAMES = json.load(f)

model = models.resnet18(weights=None)
model.fc = nn.Linear(model.fc.in_features, len(CLASS_NAMES))
model.load_state_dict(torch.load(MODEL_DIR / "best_model.pth", map_location="cpu"))
model.eval()

transform = transforms.Compose([
    transforms.Resize(256),
    transforms.CenterCrop(IMG_SIZE),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])


def classify(image: Image.Image):
    if image is None:
        return {}

    tensor = transform(image.convert("RGB")).unsqueeze(0)

    with torch.no_grad():
        outputs = model(tensor)
        probs = torch.softmax(outputs, dim=1)[0]

    return {CLASS_NAMES[i]: float(probs[i]) for i in range(len(CLASS_NAMES))}


demo = gr.Interface(
    fn=classify,
    inputs=gr.Image(type="pil", label="Upload a waste item photo"),
    outputs=gr.Label(num_top_classes=len(CLASS_NAMES), label="Prediction"),
    title="♻️ Garbage Classifier",
    description=(
        "Upload a photo of a waste item and this model will predict which "
        "recycling category it belongs to. Built with transfer learning "
        "on a pretrained ResNet18."
    ),
    examples=None,  # Add paths to a few sample images here if you'd like, e.g. ["examples/bottle.jpg"]
)

if __name__ == "__main__":
    demo.launch()
